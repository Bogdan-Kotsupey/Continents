Short Description of the Project

Es un administrador de alimentos, comidas, dietas, y compras de alimentos, que te ayuda a comprar la cantidad de alimento necesaria y a conservar el alimento fresco, por medio del uso equitativo y a tiempo de los alimentos.